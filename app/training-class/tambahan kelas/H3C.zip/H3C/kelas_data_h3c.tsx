import React from "react";

import {
	syllabus_h3cners+,
	syllabus_h3cse_rs,
      } from "./kelas_h3c_syllabus";
  

import {
  Cisco_ccna_ico,
  
} from "../../components/Bpn_imgs";

interface h3cdata {
  id: number;
  img: React.JSX.Element;
  img_big: React.JSX.Element;
  title: string;
  overview: string;
  prerequisite: string;
  level: string;
  goals: string;
  lab: string;
  intended: string;
  duration: string;
  investment: string;
  syllabus: string[];
  comingSoon: boolean;
}

const h3c_data: h3cdata[] = [
  {
    id: 1,
    img: <Mtcna_img/>,
    img_big: <Cisco_ccna_ico/>,
    title: "H3CNE-RS+",
    - duration: "5 days",  
overview: "h3cne-rs+ is a foundational certification for it professionals focusing on network routing and switching technologies
 the program equips participants with essential knowledge and skills to configure, manage, and maintain enterprise-level h3c network devices
 this certification provides a strong base for advancing to higher-level h3c certifications.",  
prerequisite: "basic computer knowledge",  
level: "Beginner",  
goals: "understand the principles of h3c network routing and switching technologies",  
lab: "yes",  
intended: "fresh graduate, noc, engineer, people who are interested in it networking field", 
    investment: "2.000.000" ,
    syllabus: syllabus_h3cners+,
    comingSoon: false,
  },

  {
    id: 2,
    img: <Mtcre_img/>,
    img_big: <Cisco_ccna_ico/>,
    title: "H3CSE-RS",
   overview: "the H3C Certified Senior Engineer for Routing & Switching (H3CSE Routing & Switching) certificate demonstrates mastery of the full range of theoretical knowledge and operational skills required to deploy campus networks, including routing, switching, multicast, QoS, and basic security features, and competence in the construction and management of large- and medium-sized complex networks,"  
prerequisite: "basic understanding of networking concepts and H3CNE qualification,"  
level: "Intermediate,"  
goals: "master advanced concepts of switching, routing, and security in H3C networks,"  
intended: "engineers working for H3C’s agents, NOC, network engineer, college students majoring in computer technology,"  
    duration: "3 Hari",
    investment: "2.500.000" ,
    syllabus: syllabus_h3cse_rs,
    comingSoon: false,
  },

 ];

export { h3c_data };